// JavaScript Document
$(document).ready(function(e) {
    $('ul.nav li.dropdown').hover(function() {
  $(this).find('.dropdown-menu').stop(true, true).delay(100).fadeIn(500);
}, function() {
  $(this).find('.dropdown-menu').stop(true, true).delay(100).fadeOut(500);
});
$('.carousel').carousel({
  interval: 4000
})
});
